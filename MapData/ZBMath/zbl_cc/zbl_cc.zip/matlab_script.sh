for dir in /home/jdoerrie/zbl_cc/MSC*; do
    echo $dir
    # echo matlab -r " M = csvread('similarities.txt'); Y = mdscale(M,2); csvwrite('mdscale.txt',Y);"
done